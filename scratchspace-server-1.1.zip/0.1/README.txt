Scratch Space and the plugins that come with it have been created by
Magnie. You use the following at your own risk and I provide no
warrenty to any damages from anything. If there are damages, bugs,
problems, glitches, security problems, etc, please report them to
MagnieTheReal@gmail.com so I can fix them. Please provide the
any details and errors within the email. Thank you for using my
plugin server. :)

Change Log:
1.0 - Date Unknown
    The base of the entire project.
    
    Added virtual_space.py which is a multiplayer game.


1.1 - February 23, 2012
    Reloading client-side plugins fixed.
    
    Added chat.py which is basically an IRC server (though it does
    not use the IRC protocol).
    
    Added auth.py which will soon give admins of the server access
    to built-in, experimental features of the plugin server.
    
    Updates on virtual_space.py